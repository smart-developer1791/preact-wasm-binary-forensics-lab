Incident package: staged binary sample.
Contact: incident-response@example.com
Callback: https://control.example.test/upload
API_TOKEN=lab_sample_token_9f32a18fbf4e40c2
